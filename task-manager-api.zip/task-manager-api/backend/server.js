const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;

// In-memory data storage initialized with sample tasks
let tasks = [
  { id: 1, title: 'Learn REST APIs' },
  { id: 2, title: 'Complete Project 2' }
];

let nextId = 3;

// MIME Types mapping for serving static frontend files
const MIME_TYPES = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'text/javascript',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon'
};

/**
 * HTTP Server Request Handler
 */
const server = http.createServer((req, res) => {
  // CORS Headers to allow requests from any origin or tool
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  // Handle preflight OPTIONS requests
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // ==========================================
  // API ENDPOINTS
  // ==========================================

  // GET /api/tasks - Retrieve all tasks
  if (req.method === 'GET' && pathname === '/api/tasks') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify(tasks));
  }

  // POST /api/tasks - Create a new task
  if (req.method === 'POST' && pathname === '/api/tasks') {
    let body = '';

    req.on('data', chunk => {
      body += chunk.toString();
    });

    req.on('end', () => {
      try {
        const payload = JSON.parse(body || '{}');
        const { title } = payload;

        // 1. Validate title exists and is a string
        if (title === undefined || title === null || typeof title !== 'string') {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: 'Task title is required and must be a string' }));
        }

        // 2. Trim whitespace
        const trimmedTitle = title.trim();

        // 3. Validate non-empty title after trimming
        if (trimmedTitle.length === 0) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: 'Task title cannot be empty or contain only whitespace' }));
        }

        // Create new task object
        const newTask = {
          id: nextId++,
          title: trimmedTitle
        };

        tasks.push(newTask);

        // Return 201 Created
        res.writeHead(201, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(newTask));
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: 'Invalid JSON body format' }));
      }
    });

    return;
  }

  // Unknown API Route Handler (404 Not Found)
  if (pathname.startsWith('/api/')) {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ error: `Cannot ${req.method} ${pathname} - Route not found` }));
  }

  // ==========================================
  // STATIC FRONTEND FILE SERVING
  // ==========================================
  let safePath = path.normalize(pathname).replace(/^(\.\.[\/\\])+/, '');
  let filePath = path.join(__dirname, '../frontend', safePath === '\\' || safePath === '/' ? 'index.html' : safePath);
  const ext = path.extname(filePath).toLowerCase();

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Page Not Found');
      } else {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Internal Server Error' }));
      }
    } else {
      res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
      res.end(content, 'utf-8');
    }
  });
});

// Start Server
server.listen(PORT, () => {
  console.log(`==================================================`);
  console.log(`Task Manager API Server running at: http://localhost:${PORT}`);
  console.log(`Endpoints:`);
  console.log(`  GET  http://localhost:${PORT}/api/tasks`);
  console.log(`  POST http://localhost:${PORT}/api/tasks`);
  console.log(`==================================================`);
});
