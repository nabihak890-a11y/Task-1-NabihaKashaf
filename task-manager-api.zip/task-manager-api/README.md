# 📝 Task Manager API – Backend REST API Development

![Project Status](https://img.shields.io/badge/Status-Complete-success)
![Node.js](https://img.shields.io/badge/Node.js-v14%2B-green)
![Express](https://img.shields.io/badge/Express.js-4.x-blue)
![JavaScript](https://img.shields.io/badge/Vanilla_JS-ES6%2B-yellow)

A clean, beginner-friendly Full-Stack Task Manager application built to demonstrate fundamental backend REST API architecture, HTTP request handling (`GET` & `POST`), server-side input validation, error responses, and frontend-to-backend integration using the Vanilla JavaScript `fetch()` API.

---

## 💡 Description (What does it do?)

This application serves as a practical demonstration of core backend development and API integration concepts:

- **Backend API Logic:** Built with Node.js & Express to manage task resources via structured REST endpoints.
- **Data Validation:** Enforces strict server-side validation rules (verifying presence, data type, and trimming whitespace from task titles).
- **HTTP Status Codes:** Returns precise standard HTTP status codes (`200 OK`, `201 Created`, `400 Bad Request`, `404 Not Found`, and `500 Internal Error`).
- **Interactive Frontend:** Features a modern, dark-themed responsive user interface built with HTML5, CSS3, and Vanilla JavaScript that seamlessly communicates with the backend in real-time.
- **In-Memory Storage:** Initialized with sample tasks for immediate testing without complex database setup.

---

## ⚡ Quick Start: How to Run

Follow these quick commands to start the project on your local machine:

### 1. Prerequisites
Ensure you have **Node.js** (v14 or higher) installed on your system.

### 2. Open Project Directory
```bash
cd C:\Users\pc\Desktop\task-manager-api
```

### 3. Install Dependencies
```bash
npm install
```

### 4. Start the Backend Server
```bash
npm start
```
*Or run directly with Node:*
```bash
node backend/server.js
```

### 5. Access the Web Application
Open your web browser and navigate to:
👉 **[http://localhost:3000](http://localhost:3000)**

---

## 📡 API Endpoints Overview

| Method | Endpoint | Description | Success Status | Error Status |
| :--- | :--- | :--- | :--- | :--- |
| **`GET`** | `/api/tasks` | Returns all available tasks | `200 OK` | `500 Internal Error` |
| **`POST`** | `/api/tasks` | Creates a new task object | `201 Created` | `400 Bad Request` |

### Example 1: GET `/api/tasks`
**Response (`200 OK`):**
```json
[
  { "id": 1, "title": "Learn REST APIs" },
  { "id": 2, "title": "Complete Project 2" }
]
```

### Example 2: POST `/api/tasks`
**Request Body (`application/json`):**
```json
{
  "title": "Build my first API"
}
```

**Response (`201 Created`):**
```json
{
  "id": 3,
  "title": "Build my first API"
}
```

### Example 3: Validation Error POST `/api/tasks`
**Request Body (`application/json`):**
```json
{
  "title": "   "
}
```

**Response (`400 Bad Request`):**
```json
{
  "error": "Task title cannot be empty or contain only whitespace"
}
```

---

## 📁 Project Structure

```text
task-manager-api/
├── backend/
│   └── server.js      # REST API server routes, input validation & error handling
├── frontend/
│   ├── index.html     # Semantic responsive markup
│   ├── style.css      # Dark mode design system & dynamic state indicators
│   └── script.js      # Fetch API communication client
├── package.json       # Node.js project manifest
└── README.md          # Top 1% developer documentation
```

---

*Crafted for Project Evaluation & Technical Portfolio — Team DecodeLabs Assignment.*
