/**
 * Task Manager Frontend Script
 * Demonstrates real REST API communication using JavaScript Fetch API.
 */

const API_BASE_URL = 'http://localhost:3000/api/tasks';

// DOM Elements
const taskForm = document.getElementById('task-form');
const taskTitleInput = document.getElementById('task-title');
const addTaskBtn = document.getElementById('add-task-btn');
const btnSpinner = document.getElementById('btn-spinner');
const btnText = addTaskBtn.querySelector('.btn-text');

const taskList = document.getElementById('task-list');
const taskCountBadge = document.getElementById('task-count');
const loadingState = document.getElementById('loading-state');
const emptyState = document.getElementById('empty-state');
const fetchErrorState = document.getElementById('fetch-error-state');
const fetchErrorMessage = document.getElementById('fetch-error-message');
const retryBtn = document.getElementById('retry-btn');
const notificationBanner = document.getElementById('notification-banner');

// Local tasks state
let tasks = [];

// ==========================================
// API FUNCTIONS
// ==========================================

/**
 * Fetch all tasks from GET /api/tasks
 */
async function fetchTasks() {
  showState('loading');
  hideNotification();

  try {
    const response = await fetch(API_BASE_URL);

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Server returned an error' }));
      throw new Error(errorData.error || `HTTP Error ${response.status}`);
    }

    // Parse JSON response
    tasks = await response.json();
    renderTasks();
  } catch (error) {
    console.error('Error fetching tasks:', error);
    fetchErrorMessage.textContent = error.message || 'Could not connect to the backend server.';
    showState('error');
  }
}

/**
 * Send a new task to POST /api/tasks
 * @param {string} title 
 */
async function addTask(title) {
  setSubmitting(true);
  hideNotification();

  try {
    const response = await fetch(API_BASE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ title: title })
    });

    const data = await response.json();

    // Check if HTTP status is 201 Created (or 200 OK)
    if (response.ok && response.status === 201) {
      // Backend returned newly created task
      tasks.push(data);
      renderTasks();
      taskTitleInput.value = '';
      showNotification(`Task "${data.title}" added successfully!`, 'success');
    } else {
      // Backend returned error (e.g. 400 Bad Request)
      showNotification(data.error || 'Failed to add task.', 'error');
    }
  } catch (error) {
    console.error('Error adding task:', error);
    showNotification('Network error: Could not reach the backend server.', 'error');
  } finally {
    setSubmitting(false);
  }
}

// ==========================================
// UI HELPER FUNCTIONS
// ==========================================

/**
 * Render task items in the DOM
 */
function renderTasks() {
  taskList.innerHTML = '';
  taskCountBadge.textContent = `${tasks.length} ${tasks.length === 1 ? 'task' : 'tasks'}`;

  if (tasks.length === 0) {
    showState('empty');
    return;
  }

  showState('list');

  tasks.forEach((task) => {
    const li = document.createElement('li');
    li.className = 'task-item';

    li.innerHTML = `
      <div class="task-info">
        <span class="task-id">ID: ${task.id}</span>
        <span class="task-title">${escapeHTML(task.title)}</span>
      </div>
    `;

    taskList.appendChild(li);
  });
}

/**
 * Manage visible state of task list area
 * @param {'loading' | 'empty' | 'error' | 'list'} state 
 */
function showState(state) {
  loadingState.classList.add('hidden');
  emptyState.classList.add('hidden');
  fetchErrorState.classList.add('hidden');
  taskList.classList.add('hidden');

  switch (state) {
    case 'loading':
      loadingState.classList.remove('hidden');
      break;
    case 'empty':
      emptyState.classList.remove('hidden');
      break;
    case 'error':
      fetchErrorState.classList.remove('hidden');
      break;
    case 'list':
      taskList.classList.remove('hidden');
      break;
  }
}

/**
 * Toggle form button loading state
 * @param {boolean} isSubmitting 
 */
function setSubmitting(isSubmitting) {
  addTaskBtn.disabled = isSubmitting;
  taskTitleInput.disabled = isSubmitting;

  if (isSubmitting) {
    btnSpinner.classList.remove('hidden');
    btnText.textContent = 'Adding...';
  } else {
    btnSpinner.classList.add('hidden');
    btnText.textContent = 'Add Task';
    taskTitleInput.focus();
  }
}

/**
 * Display top notification banner (Success / Error)
 * @param {string} message 
 * @param {'success' | 'error'} type 
 */
function showNotification(message, type) {
  notificationBanner.textContent = message;
  notificationBanner.className = `notification ${type}`;

  // Auto-hide banner after 4 seconds
  clearTimeout(window.notificationTimeout);
  window.notificationTimeout = setTimeout(() => {
    hideNotification();
  }, 4000);
}

function hideNotification() {
  notificationBanner.className = 'notification hidden';
}

/**
 * Helper to prevent XSS when rendering user input
 */
function escapeHTML(str) {
  return str.replace(/[&<>'"]/g, 
    tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
  );
}

// ==========================================
// EVENT LISTENERS
// ==========================================

// Handle Form Submission (Add Task)
taskForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const inputTitle = taskTitleInput.value;
  addTask(inputTitle);
});

// Handle Retry Button Click
retryBtn.addEventListener('click', () => {
  fetchTasks();
});

// Fetch tasks when page loads
document.addEventListener('DOMContentLoaded', fetchTasks);
